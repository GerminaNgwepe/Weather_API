import React,{useState} from 'react';
 import './App.css'
 import {GiModernCity} from 'react-icons/gi';
 import {FaTemperatureLow} from 'react-icons/fa';

 
function App() {

const apiKey='3d43e1e04c02596a76a20fb26c8e9d4e';
const [weatherData,setWeatherData]=useState([{}]);
const [city,setCity]=useState("");

const getWeather=(event)=>{
  if(event.key=="Enter"){
    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=imperial&APPID=${apiKey}`).then(
      response=>response.json()
    ).then(
      data=>{
        setWeatherData(data)
        setCity("")
      }
    )
  }
};

/* const dateBuilder=(d)=>{

  let months=["January", "February","March","April","May","June","July","August","September","October","November","December"];
  let days=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
  let day=days[d.getDay()];
  let date=d.getDate();
  let month=months[d.getMonth()];
  let year=d.getFullyear();
  return `${day} ${date} ${month} ${year}`
}; 
 */

  return (


    <div className='weather '>
      <br></br><br/><br/>
<input type="text" className='enter'
 placeholder='Enter city...'
 onChange={e=>setCity(e.target.value)}
 value={city}
 onKeyPress={getWeather}
/>

  {typeof weatherData.main === 'undefined' ?(
    <div>
      <br/>
      <p className='welcome'>Welcome to weather app .Enter your city to get weather of.</p>
    </div>

  ) : (
    <div>

<p className='city'>< GiModernCity/> {weatherData.name}</p>
{/* <p className='date'>{dateBuilder(new Date())}</p> */}

<p className='degree'>< FaTemperatureLow/> {Math.round(weatherData.main.temp)}&#176;C</p>
<p className='Mian'>{weatherData.weather[0].main}</p>

    </div>
  )}

    </div>
  )
}

export default App;